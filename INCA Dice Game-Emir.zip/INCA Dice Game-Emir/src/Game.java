import java.util.Scanner;

public class Game {
    final static int MAX_ROLL = 3;

    private static String getPlayerName() { //Scanner for the player to choose his/her name.
        System.out.println("Player 1 enter your name.");
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }

    private static boolean askPlayerRollAgain() { //Method for player to decide If they want to roll again.
        System.out.println("Stop (S) or roll again (R)?");
        Scanner sc = new Scanner(System.in);
        String choice = sc.nextLine().toUpperCase(); /*Makes the program accept the input
        even if the input is lower or upper case.*/
        while (!choice.equals("R") && !choice.equals("S")) { //Program does not accept ant input other than S or R.
            System.out.println("Please enter a valid command! (S or R)");//If so prints this and asks for a valid input.
            choice = sc.nextLine().toUpperCase();
        }
        if (choice.equals("R")) { //If the input is R, player rolls again.
            return true;
        } else { //If the input is S, player chooses that number.
            return false;
        }
    }

    private static boolean getHumanDecision(Player player) {/*This whole method checks how many rolls do
     the human player has. If it reaches to the max roll it changes turn to the computer.*/
        boolean rolling;
        if (player.getTurnRolls() < MAX_ROLL) {
            rolling = askPlayerRollAgain();
            if (rolling) {
                player.increaseTurnRolls();
            }
        } else {
            rolling = false;
        }
        return rolling;
    }

    private static boolean getComputerDecision(Player computerPlayer, Player humanPlayer) {
        /*This whole method checks how many rolls do the computer player has. If it reaches to the max roll it
        changes turn to the player. Also, it makes the computer to decide which roll it's going to accept*/
        boolean rolling;
        if (computerPlayer.getTurnRolls() < MAX_ROLL) {
            if (humanPlayer.getTurnScore()==12){
                if (Dice.compareDice(computerPlayer.getTurnScore(),62)){ /*If computer gets 62 (which is the overall
                number) or greater number according to compareDice method in Dice class, it accepts it.*/
                    rolling = false;
                }else rolling = true;
            }else
                rolling = !Dice.compareDice(computerPlayer.getTurnScore(), humanPlayer.getTurnScore());
            if (rolling) {
                computerPlayer.increaseTurnRolls();
            }
        } else {
            rolling = false;
        }
        return rolling;
    }

    /**
     * Handles the human player turn
     * @param player1 current player
     * @param numRolls - set by the opposite player
     * @return how many rolls taken
     */
    private static int playPlayerTurn(Player player1, Player player2, int numRolls) {
        boolean rolling = true;
        player1.resetTurnRolls();
        while (rolling && player1.getTurnRolls() <= numRolls) {
            System.out.println(player1.getName() + " roll number " + player1.getTurnRolls() + " of " + numRolls);
            int rollScore = Dice.getDiceScore();
            System.out.println("Score is " + rollScore);
            player1.setTurnScore(rollScore); /*Changed this code's place to 76 from 83. Because otherwise the
            computer accepts the second roll every time it starts first.*/
            if (player1.getPlayerID() == playerType.HUMAN) {
                rolling = getHumanDecision(player1);
            } else {
                rolling = getComputerDecision(player1, player2);
            }
        }
        System.out.println("");
        if(player1.getTurnRolls() >= MAX_ROLL){/*I added this condition because there was a bug that caused the
            second player having 4 lives if the first player of the round used it's all 3 roll chances */
            player1.setTurnRolls(MAX_ROLL);
        }
        return player1.getTurnRolls();
    }

    /**
     * Formatted lose message
     * @param losePlayer
     * @param winPlayer
     */
    private static void outputLoseMessage(Player losePlayer, Player winPlayer) {
        //Basically, this method is to write the round's results
        losePlayer.reduceLife();//Reduces a life from the loser.
        String winnerStr = winPlayer.getName() + " wins round ";
        if (winPlayer.getTurnScore() == Dice.INCA) { // Checks if one of the sides won with an INCA.
            winnerStr += "with an Inca (21)";
        } else
            winnerStr += winPlayer.getTurnScore();
        System.out.println(winnerStr
                + " beats "
                + losePlayer.getTurnScore()
                + ". "
                + losePlayer.getName()
                + " has "
                + losePlayer.getLives()
                + " lives left!");
        System.out.println("********************************************************");
    }

    /**
     * Checks the winner according to the rules of the game
     * @param player1
     * @param player2
     * @return number of the player that won (1 = player 1 2 = computer player)
     */
    private static playerType checkWin(Player player1, Player player2) {
        //Compares the scores and decide who is the winner and prints results according to that.
        if (player1.getTurnScore() == player2.getTurnScore()) {//Checks if it's a draw
            System.out.println("It is a draw. Score is " + player1.getTurnScore());
            System.out.println("********************************************************");
        } else {
            if (Dice.compareDice(player1.getTurnScore(), player2.getTurnScore())) {
                outputLoseMessage(player2, player1);
                return playerType.HUMAN;
            } else {
                outputLoseMessage(player1, player2);
                return playerType.COMPUTER;
            }
        }
        System.out.println("");
        return playerType.HUMAN;
    }


    /**
     * Main game method
     * Sets up the players & loops until one player has no lives left
     */
    public static void playGame() {
        //12 is the lowest score (as 11 is a good score!)
        final int MIN_SCORE = 12;
        //playing controls the main game loop
        boolean playing = true;
        //Initialise the classes for the human and computer player
        Player humanPlayer = new Player(getPlayerName(), playerType.HUMAN);
        Player computerPlayer = new Player("Computer", playerType.COMPUTER);
        //This sets up the condition for the human player to go first
        playerType winner = playerType.COMPUTER;
        int lastPlayerRolls = MAX_ROLL;
        while (playing) {
            //If computer player won the previous round human player (humanPlayer) goes first
            if (winner == playerType.COMPUTER) {
                lastPlayerRolls = playPlayerTurn(humanPlayer, computerPlayer, lastPlayerRolls);
                lastPlayerRolls = playPlayerTurn(computerPlayer, humanPlayer, lastPlayerRolls);
            } else {
                //If human player won the previous round computer player goes first
                lastPlayerRolls = playPlayerTurn(computerPlayer, humanPlayer, lastPlayerRolls);
                lastPlayerRolls = playPlayerTurn(humanPlayer, computerPlayer, lastPlayerRolls);
            }
            //Check if who was the winner of the last round
            winner = checkWin(humanPlayer, computerPlayer);
            //If one player has no lives the game is over...
            if (humanPlayer.getLives() == 0 || computerPlayer.getLives() == 0)
                //One of the players has won
                playing = false;
            else {
                //Sets up a new round of the game by resetting the turn scores & numRolls
                lastPlayerRolls = MAX_ROLL;
                humanPlayer.setTurnScore(MIN_SCORE);
                computerPlayer.setTurnScore(MIN_SCORE);
            }
        }
        if (winner == playerType.HUMAN){ //Prints the winner's name.
            System.out.println(humanPlayer.getName() + " is the winner!!!");
        }else System.out.println(computerPlayer.getName() + " is the winner!!!");
    }
}
