enum playerType {
    HUMAN,
    COMPUTER
}

public class Player {
    public static final int MAX_LIVES = 5; //Determines the max lives both players have as final.
    private String name;
    private int lives;
    private int turnScore;
    private int turnRolls;
    private playerType playerID;

    public Player(String name, playerType playerID){ //Constructor for the Player class
        lives = MAX_LIVES;
        turnScore = 0;
        this.name = name;
        this.playerID = playerID;
    }

    public void setName(String name) { //Setter for the name
        this.name = name;
    }

    public String getName() { //Getter for the name
        return name;
    }

    public int getTurnScore() { //Getter for the turn score
        return turnScore;
    }

    public void setTurnScore(int turnScore) { //Setter for the turn score
        this.turnScore = turnScore;
    }

    public int getLives() { //Getter for the lives
        return lives;
    }

    public void setTurnRolls(int turnRolls){ //Setter for turn rolls
        this.turnRolls = turnRolls;
    }

    public int getTurnRolls() { //Getter for the turn rolls
        return turnRolls;
    }

    public void resetTurnRolls() { //Resets the turn rolls to 1 when summoned
        turnRolls = 1;
    }

    public void increaseTurnRolls(){ //Increases the turn rolls by 1 when summoned
        turnRolls++;
    }

    public playerType getPlayerID() { //Getter for the PlayerID
        return playerID;
    }

    public void setPlayerID(playerType playerID) { //Setter for the Player ID
        this.playerID = playerID;
    }

    public void reduceLife(){ //When summoned lowers live of a player if they lost the round
        if (lives > 0){
            lives--;
        }
    }
}
