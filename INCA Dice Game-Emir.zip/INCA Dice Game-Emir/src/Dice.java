public class Dice {
    public static final int INCA = 21;

    private static int putGreatestDigitFirst(int num1, int num2){
        if(num1 >= num2) {//Puts the greatest digit first with the help of mods and division by 10
            return (num1*10)+num2; //It does not matter if the both numbers are the same
        }else {
            return (num2*10)+num1;
        }
    }

    private static int getDiceRoll(){
        return (int) (6*Math.random()+1);//Rolls the numbers between 6 and 1 (including 6 and 1)
    }

    public static int getDiceScore(){
        return putGreatestDigitFirst(getDiceRoll(),getDiceRoll());
        /*By using getDiceRoll method gets two numbers between 6 and 1 (including 6 and 1)
        and by using the putGreatestDigitFirst puts the greatest digit first*/
    }

    private static boolean isDouble(int score) {
        int secondDigit = score % 10;
        int firstDigit = score / 10;

        if (firstDigit == secondDigit) {//If the both division and the mod are the same identifies the number as double
            return true;
        } else {
            return false;
        }
    }

    public static boolean compareDice(int score1, int score2) {//Basically sets the winning conditions for the game
        if (score2!=INCA){ /* Player 2 always wins if it gets an INCA and if it's not a draw. So program
        checks the other conditions inside first.*/
            if (score1==INCA){
                /*If the number first player (player or computer) gets is INCA(21) which is the
                highest number in the game wins. (If it's not a draw)*/
                return true;
            }
            else if (isDouble(score1)&&!isDouble(score2)){
                /*If the number first player (player or computer) gets is a double, and it's not double or INCA
                for the second player first player wins. */
                return true;
            }
            else if (isDouble(score1)&&isDouble(score2)&&score1>score2){
                /*If both players get double but if the first players number is greater than the other
                the first player wins. */
                return true;
            }
            else if (isDouble(score2)) {
                //If the second player gets double and the first player not, then the first player looses.
                return false;
            }
            else if (score1>score2){
                /*If the first player (player or computer) gets a greater number than the other.
                And if neither of the numbers are double or INCA, first player wins. */
                return true;
            }
        }
        return false;
    }
}
