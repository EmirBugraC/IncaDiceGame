import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Test.TestCompareAll(); //If uncomment starts the Test class
        Game.playGame(); //Starts the game
        Scanner sc = new Scanner(System.in);
        System.out.println("Do you want to play again?"); /*After the game asks if player wants to play again
        with the help of a scanner.*/
        System.out.println("Press Y for Yes and any other button for No");
        String choice = sc.nextLine().toUpperCase();
        if (choice.equals("Y")){//If the choice is "Y" with the help of a while loop player plays the game again.
            Game.playGame();
        }else System.out.println("Thanks for playing!");//If not prints this and program ends.
    }
}
